/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rdr.cookie_and_session_filter.filter;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author TerminalPC
 */
public class nameFilter implements Filter {
    
    private static final boolean debug = true;

    // The filter configuration object we are associated with.  If
    // this value is null, this filter instance is not currently
    // configured. 
    private FilterConfig filterConfig = null;
    
    public nameFilter() {
        
    }     
    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        if(request.getParameter("password").equals("1234") && request.getParameter("username").equals("RDR")) {
            req.setAttribute("name", "RDR");
            req.setAttribute("song", "Soda City Funk");
            req.setAttribute("editor", "Tim Legend");
            req.getServletContext().getRequestDispatcher("/admin.jsp").forward(req, res);
        }
        chain.doFilter(request, response);
    }

    public void destroy() {     
        
    }

}
