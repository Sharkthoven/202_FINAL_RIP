/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sit.int202.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sit.int202.project.model.CourseList;
import sit.int202.project.model.Semester;
import sit.int202.project.model.Subject;

/**
 *
 * @author INT202
 */
public class CourseSevlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int semester = Integer.valueOf(request.getParameter("semester"));
        Semester temp = new Semester(semester);
        switch (semester) {
            case 1: {
                Subject sub1 = new Subject("INT100", "Information Technology Fundamentals", 3);
                Subject sub2 = new Subject("INT101", "Programming Fundamentals", 3);
                Subject sub3 = new Subject("INT102", "Web Technology", 1);
                temp.registerSubject(sub1);
                temp.registerSubject(sub2);
                temp.registerSubject(sub3);
            }
            ;
            break;
            case 2: {
                Subject sub1 = new Subject("GEN111", "Man and Ethics of Living", 3);
                Subject sub2 = new Subject("LNG120", "General English", 3);
                Subject sub3 = new Subject("INT105", "Basic SQL", 1);
                temp.registerSubject(sub1);
                temp.registerSubject(sub2);
                temp.registerSubject(sub3);
            }
            ;
            break;
        }
        request.setAttribute("semester", temp);
        getServletContext().getRequestDispatcher("/course.jsp").forward(request, response);
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
