/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sit.int202.project.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Spliterator;

/**
 *
 * @author INT202
 */
public class CourseList {

    private static List<Semester> semester = new ArrayList();

    public static Subject getSubject(int semester, String nameOfCourse) {
        if (CourseList.semester.size() < 1) {
            for (int i = 1; i <= 9; i++) {
                Semester temp = new Semester(i);
                CourseList.semester.add(temp);
                int index = CourseList.semester.indexOf(temp);
                switch (i) {
                    case 1: {
                        Subject sub1 = new Subject("INT100", "Information Technology Fundamentals", 3);
                        Subject sub2 = new Subject("INT101", "Programming Fundamentals", 3);
                        Subject sub3 = new Subject("INT102", "Web Technology", 1);
                        CourseList.semester.get(index).registerSubject(sub1);
                        CourseList.semester.get(index).registerSubject(sub2);
                        CourseList.semester.get(index).registerSubject(sub3);
                    }
                    ;
                    break;
                    case 2: {
                        Subject sub1 = new Subject("GEN111", "Man and Ethics of Living", 3);
                        Subject sub2 = new Subject("LNG120", "General English", 3);
                        Subject sub3 = new Subject("INT105", "Basic SQL", 1);
                        CourseList.semester.get(index).registerSubject(sub1);
                        CourseList.semester.get(index).registerSubject(sub2);
                        CourseList.semester.get(index).registerSubject(sub3);
                    }
                    ;
                    break;
                }

            }
        }
//        Subject temp = new Subject("INT100", "Information Technology Fundamentals", 3);
//        Subject temp1 = new Subject("GEN121", "Solving Problem", 3);
//        Subject temp2 = new Subject("INT102", "Web Technology", 1);
//        subject.add(temp);
//        subject.add(temp1);
//        subject.add(temp2);
        return CourseList.nameContains(semester, nameOfCourse);
    }

    private static Subject nameContains(int semester, String nameOfCourse) {

        Subject temp = null;
        for (Subject tempo : CourseList.semester.get(semester - 1).getRegisteredCourse()) {
            if (tempo.getSubjectId().equals(nameOfCourse)) {
                temp = tempo;
            }
        }
        return temp;
    }
}
