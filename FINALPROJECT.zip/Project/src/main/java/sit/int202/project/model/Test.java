/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sit.int202.project.model;

/**
 *
 * @author INT202
 */
public class Test {

    public static void main(String[] args) {
        Semester semester1 = new Semester(1);
        Subject s1 = CourseList.getSubject(1, "INT100");
        Subject s2 = CourseList.getSubject(1, "INT102");
        Subject s3 = CourseList.getSubject(1, "GEN111");
//        System.out.println(s1);
//        System.out.println(s2);
//        System.out.println(s3);

        semester1.registerSubject(s1);
        semester1.registerSubject(s2);

        Semester semester2 = new Semester(2);
        s1 = CourseList.getSubject(2, "GEN111");
        s2 = CourseList.getSubject(2, "INT105");

        semester2.registerSubject(s1);
        semester2.registerSubject(s2);
        CourseRegisteredHistory history = new CourseRegisteredHistory();
        history.addCourseRegistered(semester1);
        history.addCourseRegistered(semester2);

        for (Semester temp : history.getAllRegisteredCourses()) {
            System.out.println(temp.getSemesterText());
            for (Subject temp_sub : temp.getRegisteredCourse()) {
                System.out.println("\t" + temp_sub);
            }
            System.out.println("");
        }
    }
}
