/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sit.int202.project.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author INT202
 */
public class Semester {

    private int semester;
    private List<Subject> subject = new ArrayList();

    public Semester(int semester) {
        this.semester = semester;
    }

    public void registerSubject(Subject subject) {
        this.subject.add(subject);
    }

    public String getSemesterText() {
        StringBuilder str = new StringBuilder();
        switch (this.semester) {
            case 1:
                str.append("Term 1 / Year 1");
                break;
            case 2:
                str.append("Term 2 / Year 1");
                break;
            case 3:
                str.append("Term 1 / Year 2");
                break;
            case 4:
                str.append("Term 2 / Year 2");
                break;
            case 5:
                str.append("Term 1 / Year 3");
                break;
            case 6:
                str.append("Term 2 / Year 3");
                break;
            case 7:
                str.append("Term 1 / Year 4");
                break;
            case 8:
                str.append("Term 2 / Year 4");
                break;
            case 9:
                str.append("WL project");
                break;
            default:
                break;
        }
        return str.toString();
    }

    public List<Subject> getRegisteredCourse() {
        return this.subject;
    }
}
