/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sit.int202.project.model;

/**
 *
 * @author INT202
 */
public class Subject {
    private String subjectId;
    private String Title;
    private int Credit;

    public Subject(String subjectId, String Title, int Credit) {
        this.subjectId = subjectId;
        this.Title = Title;
        this.Credit = Credit;
    }

    public String getSubjectId() {
        return subjectId;
    }

    @Override
    public String toString() {
        return subjectId + " : " + Title + " , Credit : " + Credit;
    }
    
}
