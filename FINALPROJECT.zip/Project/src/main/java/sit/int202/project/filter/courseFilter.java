/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sit.int202.project.filter;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sit.int202.project.model.CourseList;
import sit.int202.project.model.CourseRegisteredHistory;
import sit.int202.project.model.Semester;
import sit.int202.project.model.Subject;

/**
 *
 * @author INT202
 */
public class courseFilter implements Filter {

    private static final boolean debug = true;

    // The filter configuration object we are associated with.  If
    // this value is null, this filter instance is not currently
    // configured. 
    private FilterConfig filterConfig = null;

    public courseFilter() {
    }

    @Override
    public void doFilter(ServletRequest sr, ServletResponse sr1, FilterChain fc) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) sr;
        HttpServletResponse response = (HttpServletResponse) sr1;
        Semester semester1 = new Semester(1);
        Subject s1 = CourseList.getSubject(1, "INT100");
        Subject s2 = CourseList.getSubject(1, "INT102");
        Subject s3 = CourseList.getSubject(1, "GEN111");
        semester1.registerSubject(s1);
        semester1.registerSubject(s2);
        request.setAttribute("subject", semester1.getRegisteredCourse());
        fc.doFilter(sr, sr1);
    }
}
