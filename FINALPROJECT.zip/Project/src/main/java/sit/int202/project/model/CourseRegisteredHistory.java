/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sit.int202.project.model;

import java.util.ArrayList;
import java.util.Collection;

/**
 *
 * @author INT202
 */
public class CourseRegisteredHistory {
    private Collection<Semester> collect = new ArrayList();

    public void addCourseRegistered(Semester semester) {
        this.collect.add(semester);
    }

    public Collection<Semester> getAllRegisteredCourses() {
        return this.collect;
    }
}
